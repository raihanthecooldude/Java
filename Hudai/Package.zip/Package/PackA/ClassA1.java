package Package.PackA;
public class ClassA1
{
	
	int x;
	public void setX(int x)
	{
		this.x=x;
	}
	public int getX(){return x;}
	public void showX(){System.out.println("X : "+x);}
}