package Package.PackA;
public class ClassA2
{
	
	int y;
	public void setY(int y)
	{
		this.y=y;
	}
	public int getY(){return y;}
	public void showY(){System.out.println("Y : "+y);}
}