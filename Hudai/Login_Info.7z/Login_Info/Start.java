public class Start
{
	public static void main(String []args)
	{
		Login_Info l = new Login_Info();
		l.setVisible(true);
	}
}
